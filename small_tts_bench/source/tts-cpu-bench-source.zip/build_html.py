"""Build one standalone HTML report (results table + base64 MP3 players + recommendation)."""
import base64
import html
import json
import subprocess
from pathlib import Path

ROOT = Path("/path/to/tts_bench")
RES = ROOT / "results"
MP3 = RES / "mp3"
OUT = ROOT / "tts_bench_2026-11.html"

# Facts from the HF API / model cards (research/hf_meta.json, research/cards/) and local safetensors counts.
META = {
    "pocket": dict(name="Pocket TTS (baseline)", repo="kyutai/pocket-tts-without-voice-cloning", released="2026-01-06",
                   params="109.5M (local file count)", license="CC-BY-4.0", langs="en (+fr, de, pt, it, es)",
                   stream="yes", voice="anna"),
    "phonon": dict(name="Phonon 31m (ptts)", repo="gradium/phonon-31m-en", released="2026-10-19",
                   params="31M + codec (41.1M file)", license="Apache-2.0", langs="en", stream="yes",
                   voice="default"),
    "linnet": dict(name="Linnet en-35m", repo="VoxRT/linnet-en-35m", released="2026-11-04",
                   params="41.4M", license="Linnet Weights License (not open source)", langs="en",
                   stream="yes", voice="linnet-en-f1"),
    "machboom": dict(name="Mach Boom", repo="SyzygyResearch/Mach-Boom", released="2026-11-10",
                     params="Phonon 31m at 3.5 bit (18.2 MB)", license="Apache-2.0", langs="en", stream="yes",
                     voice="Zoey"),
    "silencio": dict(name="Silencio-2", repo="BlueRoseLabs/Silencio-2", released="2026-10-31",
                     params="27.9M", license="CC-BY-4.0 (code MIT)", langs="en", stream="yes", voice="260"),
    "paradee": dict(name="Paradee-8M v1.3", repo="sahilmahendrakar/Paradee-8M-v1.3", released="2026-11-06",
                    params="7.9M (int8 ONNX)", license="Apache-2.0", langs="en, hi, fr, es",
                    stream="no (per sentence)", voice="af_heart"),
    "woof": dict(name="Underdog Woof", repo="ConwayResearch/Underdog-Woof", released="2026-11-05",
                 params="38.2M (int8)", license="Non-commercial", langs="en", stream="no (per piece)",
                 voice="juno"),
    # Gap-scan models (run 3). Facts from research/gap_meta.json (HF API) and research/gap_cards/.
    "klein": dict(name="Klein-TTS X1.5 Pro", repo="klein-ml/Klein-TTS-X1.5-Pro", released="2026-11-03",
                  params="13.1M (safetensors count)", license="Apache-2.0", langs="en, es, fr, it",
                  stream="no (per sentence)", voice="Sarah"),
    "inflect": dict(name="Inflect-Micro-v2", repo="owensong/Inflect-Micro-v2", released="2026-06-25",
                    params="9.36M (card)", license="Apache-2.0", langs="en", stream="no (per piece)",
                    voice="fixed single voice"),
    "sopro": dict(name="Sopro v2 turbo", repo="samuel-vitorino/sopro-v2-turbo", released="2026-08-25",
                  params="121.6M (safetensors count)", license="Apache-2.0", langs="en, pt, fr, de", stream="yes",
                  voice="clone of Pocket 'anna'"),
    "supra": dict(name="SupraTTS-1.0-Preview", repo="SupraLabs/SupraTTS-1.0-Preview", released="2026-10-15",
                  params="1.03M (safetensors count)", license="MIT", langs="en", stream="no (per sentence)",
                  voice="fixed single voice"),
    "silenciob": dict(name="Silencio (base)", repo="BlueRoseLabs/Silencio", released="2026-10-23",
                      params="33.6M (safetensors count)", license="Apache-2.0", langs="en",
                      stream="per sentence (stream() gives one chunk per sentence)", voice="librispeech_1320"),
    # Added 2026-11-16 (measured alone that day, same harness). Facts from the HF API and the model card.
    "tinyvoca": dict(name="tiny-voca", repo="n4ze3m/tiny-voca", released="2026-11-14",
                     params="4.54M (card, checked in checkpoint)", license="Apache-2.0", langs="en",
                     stream="no (per sentence)", voice="F2"),
}
ORDER = ["pocket", "phonon", "linnet", "machboom", "silencio", "paradee", "woof",
         "klein", "inflect", "sopro", "supra", "silenciob", "tinyvoca"]
NEW = {"klein", "inflect", "sopro", "supra", "silenciob"}
SENT_ORDER = ["short", "medium", "long", "numbers", "question"]

CSS = """
body{font-family:-apple-system,Segoe UI,Roboto,sans-serif;margin:0;padding:16px;background:#0f1115;color:#e6e6e6;line-height:1.45}
h1{font-size:1.4em;margin:0 0 4px} h2{font-size:1.15em;margin:28px 0 8px;border-bottom:1px solid #333;padding-bottom:4px}
.sub{color:#9aa0a6;font-size:.9em} .wrap{max-width:1200px;margin:auto}
table{border-collapse:collapse;width:100%;font-size:.86em;margin:8px 0} th,td{border:1px solid #2c2f36;padding:5px 7px;text-align:left;vertical-align:top}
th{background:#1b1e24;position:sticky;top:0} tr.base td{background:#1a1712} tr.best td{background:#122017}
.scroll{overflow-x:auto} .rec{background:#122017;border:1px solid #2f6b40;border-radius:8px;padding:12px 16px}
.warn{color:#f0b35a} .num{text-align:right;white-space:nowrap} audio{width:230px;height:32px}
.card{background:#16181d;border:1px solid #2c2f36;border-radius:8px;padding:10px 14px;margin:10px 0}
.txt{color:#cfd3d8;font-style:italic} code{background:#22252b;padding:1px 4px;border-radius:3px}
.hyp{color:#9aa0a6;font-size:.82em}
"""


def load(model: str, threads: int) -> dict:
    return json.loads((RES / f"{model}_t{threads}.json").read_text())


def mp3_b64(model: str, key: str) -> str:
    MP3.mkdir(exist_ok=True)
    src, dst = RES / "wav" / f"{model}_{key}.wav", MP3 / f"{model}_{key}.mp3"
    subprocess.run(["ffmpeg", "-y", "-loglevel", "error", "-i", str(src), "-ac", "1", "-b:a", "96k", str(dst)],
                   check=True)
    return base64.b64encode(dst.read_bytes()).decode()


def ms(x: float) -> str:
    return f"{x * 1e3:.0f} ms"


def main() -> None:
    wer = json.loads((RES / "wer.json").read_text())
    r1 = {m: load(m, 1) for m in ORDER}
    r4 = {m: load(m, 4) for m in ORDER}
    base = r1["pocket"]
    e = html.escape

    rows = []
    for m in ORDER:
        a, b, md = r1[m], r4[m], META[m]
        ttfa_max = max(v["ttfa_s"] for v in a["sentences"].values())
        cls = "base" if m == "pocket" else ("best" if m == "phonon" else "")
        tag = " <span class='warn'>(new in run 3)</span>" if m in NEW else ""
        rows.append(
            f"<tr class='{cls}'><td><b>{e(md['name'])}</b>{tag}<br><span class='sub'>{e(md['repo'])}</span></td>"
            f"<td>{md['released']}</td><td>{e(md['params'])}</td><td>{e(md['license'])}</td><td>{e(md['langs'])}</td>"
            f"<td>{e(md['stream'])}</td>"
            f"<td class='num'>{a['rtf_overall']:.3f}<br><span class='sub'>{a['speed_x']:.1f}x</span></td>"
            f"<td class='num'>{ms(a['ttfa_median_s'])}<br><span class='sub'>max {ms(ttfa_max)}</span></td>"
            f"<td class='num'>{b['rtf_overall']:.3f}<br><span class='sub'>{b['speed_x']:.1f}x</span></td>"
            f"<td class='num'>{ms(b['ttfa_median_s'])}</td>"
            f"<td class='num'>{a['peak_rss_mb']:.0f} MB</td><td class='num'>{a['load_s']:.2f} s</td>"
            f"<td class='num'>{wer[m]['wer'] * 100:.1f}%</td></tr>")

    per_rows = []
    for m in ORDER:
        cells = "".join(
            f"<td class='num'>{ms(r1[m]['sentences'][k]['ttfa_s'])} / {r1[m]['sentences'][k]['rtf']:.2f}</td>"
            for k in SENT_ORDER)
        per_rows.append(f"<tr><td>{e(META[m]['name'])}</td>{cells}</tr>")

    blocks = []
    for k in SENT_ORDER:
        text = base["sentences"][k]["text"]
        items = []
        for m in ORDER:
            s = r1[m]["sentences"][k]
            hyp = wer[m]["sentences"][k]["hyp"]
            items.append(
                f"<tr><td>{e(META[m]['name'])}<br><span class='sub'>voice {e(META[m]['voice'])}</span></td>"
                f"<td><audio controls preload='none' src='data:audio/mpeg;base64,{mp3_b64(m, k)}'></audio></td>"
                f"<td class='num'>{ms(s['ttfa_s'])}</td><td class='num'>{s['rtf']:.3f}</td>"
                f"<td class='num'>{s['audio_s']:.1f} s</td>"
                f"<td class='hyp'>{e(hyp)}</td></tr>")
        blocks.append(
            f"<div class='card'><b>{k}</b> <span class='txt'>&ldquo;{e(text)}&rdquo;</span>"
            f"<div class='scroll'><table><tr><th>Model</th><th>Audio (1 thread run)</th><th>TTFA</th><th>RTF</th>"
            f"<th>Length</th><th>Whisper transcript</th></tr>{''.join(items)}</table></div></div>")

    N = {m: META[m]["name"] for m in ORDER}
    ph, li, pa, su, kl = r1["phonon"], r1["linnet"], r1["paradee"], r1["supra"], r1["klein"]

    def tmax(m: str) -> float:
        return max(v["ttfa_s"] for v in r1[m]["sentences"].values())

    def w(m: str) -> str:
        return f"{wer[m]['wer'] * 100:.1f}%"

    rec = f"""
<div class='rec'>
<p><b>Recommendation: {e(N['phonon'])} with the <code>ptts</code> runtime (Apache-2.0). The 5 new models do not change the pick.</b></p>
<ul>
<li>It streams. First audio arrives in {ms(ph['ttfa_median_s'])} (median, max {ms(tmax('phonon'))}) on 1 thread, against {ms(base['ttfa_median_s'])} for Pocket TTS. On 4 threads it is {ms(r4['phonon']['ttfa_median_s'])}.</li>
<li>It is {base['rtf_overall'] / ph['rtf_overall']:.1f}x faster than Pocket TTS on 1 thread (RTF {ph['rtf_overall']:.3f} against {base['rtf_overall']:.3f}).</li>
<li>It has the lowest WER of the streaming models ({w('phonon')}). Peak memory is {ph['peak_rss_mb']:.0f} MB, against {base['peak_rss_mb']:.0f} MB for Pocket TTS. It needs no PyTorch.</li>
<li>It streams chunks, like Pocket TTS, so a streaming integration is small.</li>
</ul>
<p><b>New and close: {e(N['supra'])} (MIT, 1.03M parameters).</b> It is the fastest model here: RTF {su['rtf_overall']:.3f} ({su['speed_x']:.0f}x real time) on 1 thread.
It does not stream, but it makes a full sentence so fast that its first audio is {ms(su['ttfa_median_s'])} (median, max {ms(tmax('supra'))}).
<span class='warn'>It is not the pick: WER {w('supra')} (it dropped "3:45" in the numbers sentence), {su['peak_rss_mb']:.0f} MB peak memory, a "Preview" release, and its first audio grows with the length of the first sentence.</span>
Listen to it before a decision. Speed does not show the sound quality.</p>
<p><b>Runner-up for streaming: {e(N['linnet'])}.</b> First audio {ms(li['ttfa_median_s'])}, RTF {li['rtf_overall']:.3f}, {li['peak_rss_mb']:.0f} MB.
<span class='warn'>Its weights license is not open source. Its WER is {w('linnet')}, and it has no text normalisation.</span></p>
<p><b>Not for live voice:</b>
{e(N['klein'])} has {w('klein')} WER and RTF {kl['rtf_overall']:.3f}, but it does not stream: first audio {ms(kl['ttfa_median_s'])} (max {ms(tmax('klein'))}).
{e(N['paradee'])} also has {w('paradee')} WER (RTF {pa['rtf_overall']:.3f}), but its first audio waits for the full first sentence (max {ms(tmax('paradee'))}).
{e(N['sopro'])} streams, but on this AVX2-only CPU it is slower than real time (RTF {r1['sopro']['rtf_overall']:.2f} on 1 thread, {r4['sopro']['rtf_overall']:.2f} on 4 threads), and its first audio is {ms(r1['sopro']['ttfa_median_s'])}.
{e(N['inflect'])} (RTF {r1['inflect']['rtf_overall']:.2f}, WER {w('inflect')}, the highest) and {e(N['silenciob'])} (RTF {r1['silenciob']['rtf_overall']:.2f}, first audio {ms(r1['silenciob']['ttfa_median_s'])}) are too slow on 1 thread.
{e(N['woof'])} does not stream and has a non-commercial license. {e(N['machboom'])} uses the least memory ({r1['machboom']['peak_rss_mb']:.0f} MB), but it is only {r1['machboom']['speed_x']:.1f}x real time on 1 thread.</p>
<p><b>Dropped:</b> audio8-TTS-0.1B-ONNX-INT8. It did not stop on English text, and Whisper heard no words. The Method section gives the exact error.</p>
<p class='warn'>Listen to the samples before you decide. I did not rate the sound quality. The WER column shows only that Whisper understood the words.</p>
</div>"""

    claims_rows = [
        ("klein", "CPU RTF 0.022, generator only (phonemes in), desktop PC; WER 2.51% (Whisper small)",
         f"RTF {kl['rtf_overall']:.3f} end to end on 1 thread; WER {w('klein')} (Whisper large-v3, 5 sentences)"),
        ("inflect", "RTF 0.159 on 4 threads, HF CPU Upgrade (8 vCPU)",
         f"RTF {r4['inflect']['rtf_overall']:.3f} on 4 threads"),
        ("sopro", "about 300 ms first audio on a laptop CPU; RTF 0.21 streaming on an M3 CPU",
         f"{ms(r1['sopro']['ttfa_median_s'])}, RTF {r1['sopro']['rtf_overall']:.2f} on 1 thread; "
         f"{ms(r4['sopro']['ttfa_median_s'])}, RTF {r4['sopro']['rtf_overall']:.2f} on 4 threads (fp32)"),
        ("supra", "85x real time (RTF 0.0118), desktop CPU, own rtf.py",
         f"{su['speed_x']:.0f}x (RTF {su['rtf_overall']:.3f}) on 1 thread, {r4['supra']['speed_x']:.0f}x on 4 threads"),
        ("silenciob", "8.8x real time on 1 thread (Apple M4), 1.6x (Colab host)",
         f"{r1['silenciob']['speed_x']:.1f}x on 1 thread"),
    ]
    rec += ("<h2>Card claims against measured (new models)</h2>"
            "<p class='sub'>The card figures are vendor claims on other hardware. I did not measure them here.</p>"
            "<div class='scroll'><table><tr><th>Model</th><th>Card claim (vendor)</th><th>Measured here</th></tr>"
            + "".join(f"<tr><td>{e(N[m])}</td><td>{e(c)}</td><td>{e(x)}</td></tr>" for m, c, x in claims_rows)
            + "</table></div>")
    a8_git = ROOT / "src" / "audio8_TTS"
    a8_url = subprocess.run(["git", "-C", str(a8_git), "remote", "get-url", "origin"],
                            capture_output=True, text=True, check=True).stdout.strip().removesuffix(".git")
    a8_rev = subprocess.run(["git", "-C", str(a8_git), "rev-parse", "--short", "HEAD"],
                            capture_output=True, text=True, check=True).stdout.strip()

    page = f"""<!doctype html><html lang='en'><head><meta charset='utf-8'>
<meta name='viewport' content='width=device-width,initial-scale=1'><title>Small TTS benchmark, Nov 2026</title>
<style>{CSS}</style></head><body><div class='wrap'>
<h1>Small open-weight TTS models against Pocket TTS</h1>
<div class='sub'>AMD EPYC-Rome, 16 cores (AVX2, no AVX-512, no AMX), no GPU. Run 3: speed measured 2026-11-11 13:12-13:37 UTC, Whisper WER 13:38-13:49 UTC.</div>
<p class='sub'>Run 3 adds 5 models from a gap scan: {', '.join(e(N[m]) for m in ORDER if m in NEW)}. The first scan read only the top 60 entries of the Hugging Face trending and likes7d lists, so it missed these models. I dropped a sixth gap-scan model (audio8-TTS-0.1B-ONNX-INT8) because it failed. The 7 old models ran again in the same run, so all numbers come from one run.</p>
<h2>Recommendation</h2>{rec}
<h2>Results</h2>
<div class='scroll'><table>
<tr><th>Model</th><th>HF repo created</th><th>Params</th><th>License</th><th>Languages</th><th>Streaming</th>
<th>RTF, 1 thread</th><th>TTFA, 1 thread (median)</th><th>RTF, 4 threads</th><th>TTFA, 4 threads</th>
<th>Peak memory (1 thread)</th><th>Load</th><th>WER (Whisper)</th></tr>
{''.join(rows)}</table></div>
<p class='sub'>RTF = compute time / audio length (lower is better; 0.25 = 4x faster than real time). TTFA = time from the call to the first audio chunk.
Peak memory = peak RSS of the full process. WER = word error rate of Whisper large-v3 (int8) on the 5 samples, Whisper English normalizer.
A "3.45" for "3:45" in the transcript costs 0.1 on the numbers sentence, so a WER near 1.6% is a correct reading.</p>
<h2>Per sentence, 1 thread (TTFA / RTF)</h2>
<div class='scroll'><table><tr><th>Model</th>{''.join(f'<th>{k}</th>' for k in SENT_ORDER)}</tr>{''.join(per_rows)}</table></div>
<h2>Audio samples</h2>
{''.join(blocks)}
<h2>Method</h2>
<ul class='sub'>
<li>Run 3 (this report): all 12 models in one fresh run, 2026-11-11 13:12-13:37 UTC, one model at a time. The load average before the start was 0.78 on 16 cores. During the run, it was 1.3-3.8, with the benchmark process included. Whisper WER ran after the speed run, 13:38-13:49 UTC.</li>
<li>Each model ran in its own venv and process, through its own Python runtime as shipped. All loaders read local files only (HF_HUB_OFFLINE=1).</li>
<li>Each process loaded the model, did one warm-up sentence, then ran each sentence 3 times. The table shows the median.</li>
<li>Thread counts: 1 and 4. OMP, OpenBLAS and MKL threads were set to the same number, and each loader set torch.set_num_threads or the ONNX Runtime intra-op threads. The baseline voice application uses Pocket TTS on 1 thread.</li>
<li>Streaming models used their streaming API. Models without one gave audio one sentence (or piece) at a time with the model's own splitter or the benchmark splitter: {e(N['paradee'])}, {e(N['woof'])}, {e(N['klein'])}, {e(N['inflect'])}, {e(N['supra'])}. For these models, TTFA is the time for the first sentence. {e(N['silenciob'])} stream() also gives one chunk per sentence.</li>
<li>Voices: one fixed built-in voice per model (see the audio tables). {e(N['sopro'])} has no packaged voice, so it cloned the Pocket TTS "anna" clip from run 2 (results_run2/wav/pocket_long.wav, 18.7 s). Sopro ran in fp32. I did not test its optional CPU int8 mode.</li>
<li>{e(N['supra'])}: the loader gives the same pieces as MicroTTS.synthesize(), but without the short pause that synthesize() adds between sentences.</li>
<li>Linnet ran sentence by sentence in one session. Its default limit is 300 frames (24 s) per prime. The benchmark set 600.</li>
<li>Run 3 against run 2 for the 7 old models: RTF and TTFA changed by less than 20% (largest change: Linnet RTF on 1 thread, 0.225 to 0.188). WER did not change. The run 2 results are in results_run2/.</li>
<li>Dropped: audio8-TTS-0.1B-ONNX-INT8 (runtime {e(a8_url)} at commit {e(a8_rev)}, folder onnx_runtime_0_1b_int8, Python API called directly). There was no Python exception. The model did not give an end token on English text.
With the packaged "default" voice (its reference text is Chinese), the 1-thread smoke test gave no output in 900 s. On 4 threads it made 700 of 700 frames (32.5 s of audio) for a 2 s sentence, and Whisper heard no words.
Fix 1 and fix 2 used an English reference voice from the Pocket clip (18.7 s and 5.4 s, exact transcript). The result was no end token (300-400 frames of noise-like audio) or 0.2-0.4 s of silence.
The runtime's own CLI ("Welcome to audio8 TTS.", default settings) gave 11.9 s of audio, and Whisper heard only "now". Details: research/audio8_drop.md.</li>
<li>Release date = date the Hugging Face repo was created (HF API). Licenses and parameters come from the model cards and the HF API (safetensors counts where shown). Speed and quality figures from the cards are vendor claims. I did not measure them.</li>
<li>Files: <code>/path/to/tts_bench/</code> (bench.py, run_all.sh, wer.py, results/*.json, results/wav/, research/run3.log).</li>
</ul>
<h2>Sources</h2>
<ul class='sub'>{''.join(f"<li>https://huggingface.co/{META[m]['repo']}</li>" for m in ORDER)}
<li>https://huggingface.co/Edge0/audio8-TTS-0.1B-ONNX-INT8 (dropped)</li>
<li>{e(a8_url)} (onnx_runtime_0_1b_int8, commit {e(a8_rev)})</li>
<li>https://pypi.org/project/kleintts/ (0.1.0), https://pypi.org/project/sopro/ (2.2.0)</li>
<li>https://github.com/VoxRT/LinnetTTS (README)</li><li>https://github.com/sahilmahendrakar/paradee</li>
<li>https://pypi.org/project/ptts/ (0.7.0), https://pypi.org/project/linnet-tts/ (0.2.0)</li></ul>
</div></body></html>"""
    OUT.write_text(page)
    print(OUT, OUT.stat().st_size)


if __name__ == "__main__":
    main()
