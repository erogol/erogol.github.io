"""Naturalness check: score every saved 1-thread WAV with UTMOS22 strong and write results/utmos.json.

Same predictor as the Open TTS Leaderboard (huggingface/open-tts-leaderboard transformers/score_utmos.py):
SpeechMOS v1.2.0 pinned by commit, utmos22_strong, checkpoint pinned by sha256, 16 kHz mono, max 30 s, on CPU.
Run only after the speed benchmark is finished. Usage: python utmos.py [MODEL ...] (no args = all models in results/*_t1.json).
"""
import json
import os
import sys
from pathlib import Path

ROOT = Path("/path/to/tts_bench")
os.environ.setdefault("TORCH_HOME", str(ROOT / "venvs" / "utmos_hub"))  # own cache, not the shared ~/.cache

import librosa  # noqa: E402
import torch  # noqa: E402

sys.path.insert(0, str(ROOT))
from bench import SENTENCES  # noqa: E402

SPEECHMOS_REPO = "tarepan/SpeechMOS:ed25eacbfa42b99156c36ebec67a733b5dbb9b79"
SPEECHMOS_ENTRY = "utmos22_strong"
CKPT_URL = "https://github.com/tarepan/SpeechMOS/releases/download/v1.0.0/utmos22_strong_step7459_v1.pt"
CKPT_SHA256 = "38aa51ab79e2a4e09a1449758a4b37e9cbb2e8235a49662a732d33a9ba1e9bff"
SR = 16_000
MAX_SAMPLES = 30 * SR
PREDICTOR = f"UTMOS22 strong (SpeechMOS v1.2.0 {SPEECHMOS_REPO.split(':')[1][:7]}, ckpt sha256 {CKPT_SHA256[:12]})"


def load_model() -> torch.nn.Module:
    model = torch.hub.load(SPEECHMOS_REPO, SPEECHMOS_ENTRY, trust_repo=True, pretrained=False, skip_validation=True)
    ckpt = Path(torch.hub.get_dir()) / "checkpoints" / f"{CKPT_SHA256}.pt"
    if not ckpt.exists():
        ckpt.parent.mkdir(parents=True, exist_ok=True)
        torch.hub.download_url_to_file(CKPT_URL, str(ckpt), hash_prefix=CKPT_SHA256)
    model.load_state_dict(torch.load(ckpt, map_location="cpu", weights_only=True))
    return model.eval()


def main() -> None:
    torch.set_num_threads(8)
    res = ROOT / "results"
    models = sys.argv[1:] or sorted(p.name.removesuffix("_t1.json") for p in res.glob("*_t1.json"))
    path = res / "utmos.json"
    out = json.loads(path.read_text()) if path.exists() else {}
    model = load_model()
    for m in models:
        per = {}
        for key in SENTENCES:
            wav = res / "wav" / f"{m}_{key}.wav"
            if not wav.exists():
                raise SystemExit(f"missing {wav}")
            speech, _ = librosa.load(str(wav), sr=SR, mono=True)
            with torch.no_grad():
                per[key] = round(model(torch.from_numpy(speech[:MAX_SAMPLES]).float().unsqueeze(0), SR).item(), 4)
            print(f"{m:10s} {key:9s} utmos {per[key]:.3f}", flush=True)
        out[m] = {"utmos": round(sum(per.values()) / len(per), 4), "sentences": per, "predictor": PREDICTOR}
        print(f"{m:10s} MEAN utmos {out[m]['utmos']:.3f}", flush=True)
        path.write_text(json.dumps(out, indent=1))


if __name__ == "__main__":
    main()
