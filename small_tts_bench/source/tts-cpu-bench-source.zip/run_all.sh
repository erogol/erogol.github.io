#!/bin/sh
# Full benchmark: each model at 1 thread (saves WAVs) and 4 threads, one at a time.
# Run 3 (mission 9a270dd97d7f): 7 old models + 5 gap-scan models (audio8 dropped, see research/audio8_drop.md).
umask 077
B=/path/to/tts_bench
export HF_HUB_OFFLINE=1 HF_HUB_DISABLE_TELEMETRY=1 KLEINTTS_NO_AUTO_INSTALL=1
cd "$B" || exit 1
mkdir -p "$B/results"
echo "=== START $(date -u +%H:%M:%S) $(uptime)"
for spec in pocket:/usr/bin/python3 silencio:$B/venvs/silencio/bin/python phonon:$B/venvs/ptts/bin/python \
            machboom:$B/venvs/machboom/bin/python linnet:$B/venvs/linnet/bin/python woof:$B/venvs/woof/bin/python \
            paradee:$B/venvs/paradee/bin/python klein:$B/venvs/klein/bin/python inflect:$B/venvs/inflect/bin/python \
            sopro:$B/venvs/sopro/bin/python supra:$B/venvs/supra/bin/python silenciob:$B/venvs/silenciob/bin/python; do
  name=${spec%%:*}
  py=${spec#*:}
  for t in 1 4; do
    if [ "$t" = 1 ]; then extra="--save-wav"; else extra=""; fi
    echo "=== $name threads=$t $(date -u +%H:%M:%S)"
    OMP_NUM_THREADS=$t OPENBLAS_NUM_THREADS=$t MKL_NUM_THREADS=$t "$py" "$B/bench.py" --model "$name" --threads "$t" --reps 3 $extra 2>&1 | grep -v -i -E "warn|^INFO|^DEBUG" \
      || echo "FAILED $name t=$t"
    [ -f "$B/results/${name}_t$t.json" ] || echo "MISSING JSON $name t=$t"
  done
done
echo "=== ALL DONE $(date -u +%H:%M:%S) $(uptime)"
