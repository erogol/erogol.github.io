"""TTS benchmark harness: one model and one thread count per process.

Measures load time, time to first audio (TTFA), total synthesis time, real-time factor (RTF = compute / audio)
and peak resident memory. Streaming models use their own streaming API. Non-streaming models are fed
piece by piece through their own sentence splitter, so TTFA is the time to the first piece.
"""
import argparse
import json
import os
import re
import resource
import statistics
import sys
import time
import wave
from pathlib import Path
from typing import Callable, Iterator

import numpy as np

ROOT = Path("/path/to/tts_bench")
MODELS = ROOT / "models"

SENTENCES = {
    "short": "Hi, I'm ready when you are.",
    "medium": "The weather in Munich looks clear today, so it is a good afternoon for a long walk with the dog.",
    "long": (
        "Before we start the review, let me summarize the main points from yesterday's meeting. "
        "The team agreed to move the release by one week, because the new speech model still needs more testing "
        "on slower devices. After that, we will collect feedback from early users and decide which features stay "
        "in the final version."
    ),
    "numbers": "Your appointment is on March 14th at 3:45 p.m., and the total cost is $1,280.50, including 19% VAT.",
    "question": "Do you want me to book the table for eight people, or should I wait until you check with your friends?",
}
WARMUP = "This is a short warm up sentence, so the first real run is not slow."

Stream = Callable[[str, int], Iterator[np.ndarray]]


def to_np(x) -> np.ndarray:
    """Convert a torch tensor or array-like chunk to a flat float32 numpy array."""
    if hasattr(x, "detach"):
        x = x.detach().cpu().float().numpy()
    return np.asarray(x, dtype=np.float32).reshape(-1)


def split_sentences(text: str) -> list[str]:
    return [s for s in re.split(r"(?<=[.!?])\s+", text.strip()) if s]


def load_pocket(threads: int) -> tuple[int, Stream, dict]:
    import torch
    from pocket_tts import TTSModel

    model = TTSModel.load_model()
    state = model.get_state_for_audio_prompt("anna")
    torch.set_num_threads(threads)

    def stream(text: str, seed: int) -> Iterator[np.ndarray]:
        torch.manual_seed(seed)
        for c in model.generate_audio_stream(state, text):
            yield to_np(c)

    return model.sample_rate, stream, {"voice": "anna", "runtime": "pocket_tts (PyTorch)"}


def load_silencio(threads: int) -> tuple[int, Stream, dict]:
    sys.path.insert(0, str(MODELS / "Silencio-2"))
    import torch
    from silencio2 import Silencio2TTS

    tts = Silencio2TTS.from_pretrained(str(MODELS / "Silencio-2"), device="cpu")
    torch.set_num_threads(threads)

    def stream(text: str, seed: int) -> Iterator[np.ndarray]:
        for c in tts.stream(text, voice="260", seed=seed):
            yield to_np(c)

    return tts.sample_rate, stream, {"voice": "260", "runtime": "silencio2 (PyTorch, Pocket TTS core)"}


def load_phonon(threads: int) -> tuple[int, Stream, dict]:
    import ptts

    ptts.set_num_threads(threads)
    tts = ptts.TTS(str(MODELS / "phonon-31m-en"), quant="q8_0", lang="en")

    def stream(text: str, seed: int) -> Iterator[np.ndarray]:
        with tts.stream(text, seed=seed) as audio:
            for c in audio:
                yield to_np(c)

    return tts.sample_rate, stream, {"voice": "default", "runtime": f"ptts 0.7.0 (Rust), quant={tts.quant}"}


def load_machboom(threads: int) -> tuple[int, Stream, dict]:
    d = MODELS / "Mach-Boom"
    sys.path.insert(0, str(d))
    from mach import MachBoom

    tts = MachBoom(str(d / "mach-boom.bin"), voices_dir=str(d / "voices"), tokenizer=str(d / "tokenizer.json"))

    def stream(text: str, seed: int) -> Iterator[np.ndarray]:
        for c in tts.synth_stream(text, "Zoey", seed=seed, threads=threads, first=2):
            yield to_np(c)

    return 24000, stream, {"voice": "Zoey", "runtime": f"mach.py + C kernels ({tts.k.isa}), first=2"}


def load_linnet(threads: int) -> tuple[int, Stream, dict]:
    import linnet_tts

    d = MODELS / "linnet-en-35m"
    model = linnet_tts.Model(d / "linnet-en-35m.fp16.safetensors", d / "tokenizer.model")
    model.set_threads(threads)
    voice = model.load_voice(d / "voices" / "linnet-en-f1.npy")

    def stream(text: str, seed: int) -> Iterator[np.ndarray]:
        session = model.session(voice, seed=seed, threads=threads, max_frames=600)
        for sentence in split_sentences(text):
            session.prime(sentence)
            for c in session:
                yield to_np(c)

    return model.sample_rate, stream, {"voice": "linnet-en-f1", "runtime": "linnet-tts 0.2.0 (Rust, fp16), per sentence"}


def load_woofmira(threads: int) -> tuple[int, Stream, dict]:
    return load_woof(threads, voice="mira")


def load_woof(threads: int, voice: str = "juno") -> tuple[int, Stream, dict]:
    d = MODELS / "Underdog-Woof"
    sys.path.insert(0, str(d))
    from underdog_woof import Woof
    from underdog_woof.runtime import RNG
    from underdog_woof.textsplit import split_text

    tts = Woof(voice=voice)

    def stream(text: str, seed: int) -> Iterator[np.ndarray]:
        # Same steps as Woof.__call__, but yields each piece as soon as it is ready.
        RNG.seed(seed)
        t = tts.norm(text) if tts.norm is not None else text
        for piece in split_text(t) or [t]:
            yield to_np(tts._piece(piece))

    return tts.sr, stream, {"voice": voice, "runtime": "numpy int8, per piece"}


def load_paradee(threads: int) -> tuple[int, Stream, dict]:
    from paradee import Paradee

    d = MODELS / "Paradee-8M-v1.3"
    tts = Paradee(model_path=str(d / "onnx" / "paradee_int8.onnx"), config_path=str(d / "config.json"), threads=threads)

    def stream(text: str, seed: int) -> Iterator[np.ndarray]:
        # Same steps as Paradee.__call__, but yields each sentence as soon as it is ready.
        for ps in tts._chunks(text, "af_heart"):
            yield to_np(tts.generate_from_phonemes(ps, 1.0, "af_heart"))

    return 24000, stream, {"voice": "af_heart", "runtime": "onnxruntime int8, per sentence"}


# Reference clip for cloning-only models without a packaged voice (Pocket TTS "anna", run 2).
REF_CLIP = ROOT / "results_run2" / "wav" / "pocket_long.wav"


def load_klein(threads: int) -> tuple[int, Stream, dict]:
    import torch
    from kleintts import KleinTTS

    tts = KleinTTS.from_pretrained(str(MODELS / "Klein-TTS-X1.5-Pro"), device="cpu", auto_install=False)
    torch.set_num_threads(threads)

    def stream(text: str, seed: int) -> Iterator[np.ndarray]:
        # No streaming API: one sentence per call.
        for s in split_sentences(text):
            yield to_np(tts.tts(s, voice="Sarah", speed=1.0, seed=seed).waveform)

    return tts.sample_rate, stream, {"voice": "Sarah", "runtime": "kleintts 0.1.0 (PyTorch, misaki + spaCy), per sentence"}


def load_inflect(threads: int) -> tuple[int, Stream, dict]:
    import torch

    d = MODELS / "Inflect-Micro-v2"
    sys.path.insert(0, str(d))
    from inference import InflectTTS, split_text

    tts = InflectTTS(d, device="cpu")
    torch.set_num_threads(threads)

    def stream(text: str, seed: int) -> Iterator[np.ndarray]:
        # No streaming API: the model's own splitter, one piece per call.
        for piece in split_text(text):
            _, wav = tts.synthesize(piece, seed=seed)
            yield to_np(wav)

    return tts.sample_rate, stream, {"voice": "fixed single voice", "runtime": "PyTorch VITS, per sentence"}


def load_sopro(threads: int) -> tuple[int, Stream, dict]:
    import torch
    from sopro import SoproTTS

    tts = SoproTTS.from_pretrained(str(MODELS / "sopro-v2-turbo"), device="cpu")
    torch.set_num_threads(threads)
    ref = tts.prepare_reference(ref_audio_path=str(REF_CLIP), stream=True)

    def stream(text: str, seed: int) -> Iterator[np.ndarray]:
        torch.manual_seed(seed)
        for c in tts.stream(text, ref=ref, lang="en"):
            yield to_np(c)

    return tts.sample_rate, stream, {"voice": "clone of Pocket 'anna' (results_run2/wav/pocket_long.wav)",
                                     "runtime": "sopro 2.2.0 (PyTorch fp32), streaming"}


def load_audio8(threads: int) -> tuple[int, Stream, dict]:
    sys.path.insert(0, str(ROOT / "src" / "audio8_TTS" / "onnx_runtime_0_1b_int8"))
    from arktts_runtime import ArkTtsRuntime

    rt = ArkTtsRuntime(MODELS / "audio8-TTS-0.1B-ONNX-INT8", MODELS / "audio8_voices", threads=threads)

    def stream(text: str, seed: int) -> Iterator[np.ndarray]:
        for ev in rt.stream(text=text, voice="default", max_new_tokens=1024, temperature=0.7, top_p=0.9, top_k=50, seed=seed):
            if ev["type"] == "audio_chunk":
                yield to_np(ev["audio"])

    return int(rt.manifest["sample_rate"]), stream, {"voice": "default (packaged reference codes)",
                                                     "runtime": "onnxruntime int8 (arktts_runtime), streaming, chunk_frames=12"}


def load_supra(threads: int) -> tuple[int, Stream, dict]:
    import torch

    d = MODELS / "SupraTTS-1.0-Preview"
    sys.path.insert(0, str(d))
    from microtts import MicroTTS
    from microtts.g2p import phonemize
    from microtts.synthesize import SAMPLE_RATE

    tts = MicroTTS.load(str(d), device="cpu")
    torch.set_num_threads(threads)

    def stream(text: str, seed: int) -> Iterator[np.ndarray]:
        # Same steps as MicroTTS.synthesize, but yields each piece as soon as it is ready.
        for part in tts._chunks(text):
            ids, _ = phonemize(part)
            yield to_np(tts._synthesize_single(ids))

    return SAMPLE_RATE, stream, {"voice": "fixed single voice", "runtime": "PyTorch, per sentence"}


def load_silenciob(threads: int) -> tuple[int, Stream, dict]:
    import torch

    d = MODELS / "Silencio"
    sys.path.insert(0, str(d))
    from silencio import SilencioTTS
    from silencio.tts import SAMPLE_RATE

    tts = SilencioTTS.from_pretrained(str(d), device="cpu")
    torch.set_num_threads(threads)

    def stream(text: str, seed: int) -> Iterator[np.ndarray]:
        for c in tts.stream(text, voice="librispeech_1320", seed=seed):
            yield to_np(c)

    return SAMPLE_RATE, stream, {"voice": "librispeech_1320", "runtime": "silencio (PyTorch fp32), per sentence"}


def load_tinyvoca(threads: int) -> tuple[int, Stream, dict]:
    import torch

    d = MODELS / "tiny-voca"
    os.environ["DIZIONE_DATA"] = str(d / "phonemizer")
    from tiny_voca.infer import _voice, finished, limit_peak, load_model, match_frontend, sentences
    from tiny_voca.text import NothingToPronounce, phonemize

    ckpt = d / "tiny-voca.pt"
    match_frontend(ckpt)
    model = load_model(ckpt, "cpu")
    torch.set_num_threads(threads)

    def stream(text: str, seed: int) -> Iterator[np.ndarray]:
        # Same steps as speak_text (sentences of finished(text), seed + index), but yields each sentence
        # as soon as it is ready. The peak limit is applied per sentence, not over the whole text.
        with torch.inference_mode():
            for i, s in enumerate(sentences(finished(text))):
                try:
                    phones = phonemize(s)
                except NothingToPronounce:
                    continue
                wave, _ = _voice(model, phones, "F2", 1.0, 0.0, seed + i, 1.0)
                yield to_np(limit_peak(wave))

    return model.config.sample_rate, stream, {"voice": "F2", "runtime": "tiny_voca (PyTorch fp32), per sentence"}


def load_nanoedge(threads: int) -> tuple[int, Stream, dict]:
    import torch

    d = MODELS / "nano-edge-tts"
    sys.path.insert(0, str(d))
    from kokoro import KPipeline
    from nano_edge_tts import load

    torch.set_num_threads(threads)
    pipe = KPipeline(lang_code="a", model=load(str(d)), repo_id="hexgrad/Kokoro-82M")

    def stream(text: str, seed: int) -> Iterator[np.ndarray]:
        # Kokoro text side (G2P, timing, pitch) + nano-edge decoder; fed one sentence at a time.
        for s in split_sentences(text):
            for r in pipe(s, voice="af_heart"):
                if r.audio is not None:
                    yield to_np(r.audio)

    return 24000, stream, {"voice": "af_heart", "runtime": "kokoro 0.9.4 KPipeline + nano-edge decoder (PyTorch fp32), per sentence"}


def load_pivo(threads: int) -> tuple[int, Stream, dict]:
    d = MODELS / "PiVo-1.4M"
    sys.path.insert(0, str(d))
    from pivo import PiVo

    tts = PiVo(d, threads=threads)

    def stream(text: str, seed: int) -> Iterator[np.ndarray]:
        # PiVo streams 10 ms frames after duration prediction; fed one sentence at a time (512-token input limit).
        for s in split_sentences(text):
            for c in tts.iter_audio(s, voice="Pi"):
                yield to_np(c)

    return tts.sample_rate, stream, {"voice": "Pi", "runtime": "pivo onnxruntime (own runtime), streaming per sentence"}


def load_supertonic(threads: int) -> tuple[int, Stream, dict]:
    from supertonic import TTS

    tts = TTS(model="supertonic-3", model_dir=MODELS / "supertonic-3", auto_download=False,
              intra_op_num_threads=threads, inter_op_num_threads=1)
    style = tts.get_voice_style("F1")

    def stream(text: str, seed: int) -> Iterator[np.ndarray]:
        # Same call as TTS.synthesize (default 8 steps, speed 1.05), one sentence at a time.
        for s in split_sentences(text):
            wav, _ = tts.synthesize(s, voice_style=style, lang="en")
            yield to_np(wav)

    return tts.sample_rate, stream, {"voice": "F1", "runtime": "supertonic 1.3.1 (onnxruntime fp32), per sentence"}


def load_inflect3(threads: int) -> tuple[int, Stream, dict]:
    d = MODELS / "Inflect-Micro-v3"
    sys.path.insert(0, str(d))
    import synthesize as syn

    root = syn.verify_candidate(d)
    normalizer = syn.load_numeric(root)
    core, frontend, model, torch, _ = syn.load_runtime(root, "micro", "cpu")
    torch.set_num_threads(threads)  # load_runtime sets 2 threads

    def stream(text: str, seed: int) -> Iterator[np.ndarray]:
        # Same steps as render_prepared (numeric frontend, phonemes, seed + index), one sentence at a time.
        i = 0
        for s in split_sentences(text):
            for chunk in syn.prepare_text(s, normalizer)["chunks"]:
                ps = core.prepare_phonemes(chunk, model.vocab, g2p=frontend)["ps"]
                with torch.inference_mode():
                    yield to_np(model.synthesize_phonemes(ps, "cassidy", seed=(42 + i) % 2**32)["audio"])
                i += 1

    return 24000, stream, {"voice": "cassidy", "runtime": "Inflect Micro v3 (PyTorch fp32), per sentence"}


def load_kokoro(threads: int) -> tuple[int, Stream, dict]:
    import torch
    from kokoro import KPipeline

    torch.set_num_threads(threads)
    pipe = KPipeline(lang_code="a", repo_id="hexgrad/Kokoro-82M")  # local HF cache, snapshot f3ff357

    def stream(text: str, seed: int) -> Iterator[np.ndarray]:
        # Kokoro's own pipeline yields one audio piece per text chunk; fed one sentence at a time like nanoedge.
        for s in split_sentences(text):
            for r in pipe(s, voice="af_heart"):
                if r.audio is not None:
                    yield to_np(r.audio)

    return 24000, stream, {"voice": "af_heart", "runtime": "kokoro 0.9.4 KPipeline (PyTorch fp32), per sentence"}


def load_inflectmini(threads: int) -> tuple[int, Stream, dict]:
    import importlib.util

    root = MODELS / "Inflect-Mini-v3" / "core"
    spec = importlib.util.spec_from_file_location("_inflect_mini_core", root / "synthesize.py")
    syn = importlib.util.module_from_spec(spec)
    sys.modules["_inflect_mini_core"] = syn
    spec.loader.exec_module(syn)
    syn.verify(root)
    cli, runtime, _ = syn.load_selected("mini", "cpu", "base", "canonical", root)
    core, frontend, model, torch, _ = runtime
    normalizer = cli.load_numeric(root / "baseline")
    torch.set_num_threads(threads)  # load_runtime sets 2 threads

    def stream(text: str, seed: int) -> Iterator[np.ndarray]:
        # Same steps as core/synthesize.py render (base profile, seed + index), one sentence at a time.
        i = 0
        for s in split_sentences(text):
            for chunk in cli.prepare_text(s, normalizer, "conservative")["chunks"]:
                ps = core.prepare_phonemes(chunk, model.vocab, g2p=frontend)["ps"]
                with torch.inference_mode():
                    yield to_np(model.synthesize_phonemes(ps, "cassidy", seed=(42 + i) % 2**32)["audio"])
                i += 1

    return 24000, stream, {"voice": "cassidy", "runtime": "Inflect Mini v3 base profile, canonical CPU runtime (PyTorch fp32), per sentence"}


def load_scylla(threads: int) -> tuple[int, Stream, dict]:
    d = MODELS / "scyllasband-rt"
    sys.path.insert(0, str(d))
    from scyllasband import ScyllasBandRuntime
    from scyllasband.planner import records_from_text

    rt = ScyllasBandRuntime.from_bundle(d / "scyllasband" / "models" / "litert", threads=threads)
    rt.warmup(voice_id="scylla")

    def stream(text: str, seed: int) -> Iterator[np.ndarray]:
        # The runtime's own passage streaming (synthesize_stream): yields each passage's audio as it is ready.
        sr = None
        for ev in rt.synthesize_stream(records_from_text(text, voice="scylla", language="en_us"), seed=seed):
            if ev.type == "audio_chunk" and ev.audio is not None:
                yield to_np(ev.audio)

    return 24000, stream, {"voice": "scylla", "runtime": "scyllasband 3.0.0 Python engine, LiteRT bundle v4-20261106-apple, streaming"}


LOADERS = {
    "scylla": load_scylla,
    "inflectmini": load_inflectmini,
    "kokoro": load_kokoro,
    "woofmira": load_woofmira,
    "pivo": load_pivo,
    "supertonic": load_supertonic,
    "inflect3": load_inflect3,
    "nanoedge": load_nanoedge,
    "tinyvoca": load_tinyvoca,
    "pocket": load_pocket,
    "silencio": load_silencio,
    "phonon": load_phonon,
    "machboom": load_machboom,
    "linnet": load_linnet,
    "woof": load_woof,
    "paradee": load_paradee,
    "klein": load_klein,
    "inflect": load_inflect,
    "sopro": load_sopro,
    "audio8": load_audio8,
    "supra": load_supra,
    "silenciob": load_silenciob,
}


def rss_mb() -> float:
    for line in Path("/proc/self/status").read_text().splitlines():
        if line.startswith("VmRSS:"):
            return int(line.split()[1]) / 1024
    raise RuntimeError("VmRSS not found")


def write_wav(path: Path, audio: np.ndarray, sr: int) -> None:
    pcm = (np.clip(np.nan_to_num(audio), -1, 1) * 32767).round().astype("<i2")
    with wave.open(str(path), "wb") as w:
        w.setnchannels(1)
        w.setsampwidth(2)
        w.setframerate(sr)
        w.writeframes(pcm.tobytes())


def run_once(stream: Stream, text: str, seed: int) -> tuple[float, float, list[np.ndarray]]:
    t0 = time.perf_counter()
    first = None
    parts = []
    for c in stream(text, seed):
        if first is None and c.size > 0:
            first = time.perf_counter() - t0
        parts.append(c)
    total = time.perf_counter() - t0
    if first is None:
        raise RuntimeError(f"no audio for {text!r}")
    return first, total, parts


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--model", required=True, choices=sorted(LOADERS))
    ap.add_argument("--threads", type=int, default=1)
    ap.add_argument("--reps", type=int, default=3)
    ap.add_argument("--out", type=Path, default=ROOT / "results")
    ap.add_argument("--save-wav", action="store_true")
    ap.add_argument("--smoke", action="store_true", help="one rep, short sentence only, no JSON")
    a = ap.parse_args()

    rss0 = rss_mb()
    t0 = time.perf_counter()
    sr, stream, info = LOADERS[a.model](a.threads)
    load_s = time.perf_counter() - t0
    rss_load = rss_mb()
    w_first, w_total, _ = run_once(stream, WARMUP, 0)
    print(f"[{a.model} t={a.threads}] load {load_s:.2f}s, warm-up ttfa {w_first*1e3:.0f} ms total {w_total:.2f}s", flush=True)

    sentences = {"short": SENTENCES["short"]} if a.smoke else SENTENCES
    reps = 1 if a.smoke else a.reps
    wav_dir = a.out / "wav"
    wav_dir.mkdir(parents=True, exist_ok=True)
    per = {}
    for key, text in sentences.items():
        runs = []
        for r in range(reps):
            first, total, parts = run_once(stream, text, 0)
            audio = np.concatenate(parts)
            dur = len(audio) / sr
            runs.append({"ttfa_s": first, "total_s": total, "audio_s": dur})
            if r == 0 and (a.save_wav or a.smoke):
                suffix = "_smoke" if a.smoke else ""
                write_wav(wav_dir / f"{a.model}_{key}{suffix}.wav", audio, sr)
        ttfa = statistics.median(x["ttfa_s"] for x in runs)
        total = statistics.median(x["total_s"] for x in runs)
        audio_s = statistics.median(x["audio_s"] for x in runs)
        per[key] = {"text": text, "ttfa_s": ttfa, "total_s": total, "audio_s": audio_s, "rtf": total / audio_s, "runs": runs}
        print(f"  {key:9s} ttfa {ttfa*1e3:7.0f} ms  total {total:6.2f}s  audio {audio_s:6.2f}s  rtf {total/audio_s:.3f}", flush=True)

    peak_mb = resource.getrusage(resource.RUSAGE_SELF).ru_maxrss / 1024
    sum_total = sum(v["total_s"] for v in per.values())
    sum_audio = sum(v["audio_s"] for v in per.values())
    summary = {
        "model": a.model,
        "threads": a.threads,
        "sample_rate": sr,
        "info": info,
        "env_threads": {k: os.environ.get(k) for k in ("OMP_NUM_THREADS", "OPENBLAS_NUM_THREADS", "MKL_NUM_THREADS")},
        "load_s": load_s,
        "rss_start_mb": rss0,
        "rss_after_load_mb": rss_load,
        "peak_rss_mb": peak_mb,
        "rtf_overall": sum_total / sum_audio,
        "speed_x": sum_audio / sum_total,
        "ttfa_median_s": statistics.median(v["ttfa_s"] for v in per.values()),
        "ttfa_short_s": per["short"]["ttfa_s"],
        "sentences": per,
    }
    print(f"  overall rtf {summary['rtf_overall']:.3f} ({summary['speed_x']:.1f}x), peak rss {peak_mb:.0f} MB", flush=True)
    if not a.smoke:
        a.out.mkdir(parents=True, exist_ok=True)
        (a.out / f"{a.model}_t{a.threads}.json").write_text(json.dumps(summary, indent=1))


if __name__ == "__main__":
    main()
