"""Intelligibility check: transcribe every benchmark WAV with faster-whisper and compute WER per model.

Run only after the speed benchmark is finished, because it uses many CPU cores.
"""
import json
import sys
from pathlib import Path

import jiwer
from faster_whisper import WhisperModel
from transformers.models.whisper.english_normalizer import EnglishTextNormalizer

ROOT = Path("/path/to/tts_bench")
sys.path.insert(0, str(ROOT))
from bench import SENTENCES  # noqa: E402

MODELS = ["pocket", "silencio", "phonon", "machboom", "linnet", "woof", "paradee",
          "klein", "inflect", "sopro", "supra", "silenciob", "tinyvoca"]


def main() -> None:
    norm = EnglishTextNormalizer({})
    asr = WhisperModel("large-v3", device="cpu", compute_type="int8", cpu_threads=8)
    out: dict = {}
    for m in MODELS:
        refs, hyps, per = [], [], {}
        for key, text in SENTENCES.items():
            wav = ROOT / "results" / "wav" / f"{m}_{key}.wav"
            if not wav.exists():
                print(f"missing {wav}", flush=True)
                continue
            segs, _ = asr.transcribe(str(wav), language="en", beam_size=1, vad_filter=False)
            hyp = " ".join(s.text.strip() for s in segs)
            r, h = norm(text), norm(hyp)
            per[key] = {"hyp": hyp, "wer": jiwer.wer(r, h) if r else 0.0}
            refs.append(r)
            hyps.append(h)
            print(f"{m:9s} {key:9s} wer {per[key]['wer']:.3f} | {hyp}", flush=True)
        if refs:
            out[m] = {"wer": jiwer.wer(refs, hyps), "sentences": per}
            print(f"{m:9s} OVERALL wer {out[m]['wer']:.3f}", flush=True)
    (ROOT / "results" / "wer.json").write_text(json.dumps(out, indent=1))


if __name__ == "__main__":
    main()
