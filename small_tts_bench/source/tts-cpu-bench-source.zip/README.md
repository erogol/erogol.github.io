# CPU text-to-speech benchmark source

This archive contains the measurement and report scripts for the public benchmark at
https://erogol.com/small_tts_bench/. Eren Golge (https://erogol.com) prepared the benchmark.
The site was last tested on 2026-11-11.

## Contents

- `bench.py`: model loaders, three-run timing measurements, and optional WAV output.
- `run_all.sh`: one-process-per-model runner for one and four CPU threads.
- `wer.py`: Whisper large-v3 transcription and normalized word error rate calculation.
- `build_html.py`: the original report generator. It creates embedded audio. The public site uses separate MP3 files.
- `research/audio8_drop.md`: the excluded audio8 model test record.

## Reproduce the measurements

The scripts require Python 3, NumPy, and the runtime for each model. The WER script
also requires faster-whisper, jiwer, and Transformers. Model licenses and installation
requirements differ. Read each linked model card before use.

1. Put these files in a working directory.
2. Download the model files into `models/`. Download the audio8 runtime into `src/audio8_TTS/` only for its drop test.
3. Create one Python environment for each runtime. Set each interpreter path in `run_all.sh`.
4. For the Sopro cloning test, put the Pocket long-sample WAV at `results_run2/wav/pocket_long.wav`.
5. Run `sh run_all.sh`. It runs models one at a time and writes measurements to `results/`.
6. Run `python3 wer.py` after the speed measurements. It writes `results/wer.json`.
7. Run `python3 build_html.py` to make the original report. FFmpeg is necessary for MP3 conversion.

The scripts use `/path/to/tts_bench` as the working directory. Change `ROOT` in
`bench.py`, `wer.py`, and `build_html.py`, and `B` in `run_all.sh`, to your working
directory. Model weights, environments, caches, logs, and generated audio are not included.

## Scope

The measurement host has a 16-core AMD EPYC Rome CPU with AVX2. It has no AVX-512,
AMX, or GPU. 12 of the 14 models ran on 2026-11-11. tiny-voca and nano-edge-tts ran alone on 2026-11-16 with the same harness.
Each text ran three times. The displayed value is the median. The source includes no audio8 result because its
output was not intelligible and it did not stop reliably. See the drop record.

The result JSON files and MP3 samples are available from the public site. The public
`results/results.json` combines the original per-model measurements. The public
`results/wer.json` preserves the original transcription measurements.
