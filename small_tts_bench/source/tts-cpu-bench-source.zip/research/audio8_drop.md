# audio8-TTS-0.1B-ONNX-INT8: dropped (mission 9a270dd97d7f, 2026-11-11)

Runtime: GitHub Edge0-AI/audio8_TTS @ 1d64afc (2026-11-02), folder onnx_runtime_0_1b_int8, called directly
(ArkTtsRuntime.iter_codes / stream / decode_codes, and once through its own `python -m arktts_runtime.cli`).
Host: 16-core AVX2-only x86 CPU (no AVX-512, no VNNI), onnxruntime from the runtime requirements.txt.

No Python exception occurs. The failure: the model does not stop (no EOS token) on English text,
and Whisper large-v3 finds no intelligible speech in the output.

| Try | Voice / reference | Text | Frames (cap) | Result |
|---|---|---|---|---|
| smoke | packaged "default" (reference text is Chinese) | "Hi, I'm ready when you are." | no output in 900 s at 1 thread (timeout) | killed by timeout 900 |
| check | default, seed 0 and 42, 4 threads | same | 700/700, no EOS | 32.5 s of audio for a 2 s sentence; Whisper transcript empty |
| fix 1 | "anna" = Pocket clip pocket_long.wav (18.7 s) + exact English transcript, registered with the packaged codec encoder | short / medium | seed 0: 400/400, no EOS; seed 42: EOS after 8 frames | 18.6 s noise-like audio / 0.37 s silence (rms 0.0008) |
| fix 2 | "anna5" = pocket_medium.wav (5.4 s) + exact transcript | short / question | 300/300 no EOS, or EOS after 4-6 frames | 13.9 s audio (Whisper: "...") or 0.2-0.3 s silence (Whisper hallucinates "Thank you.") |
| sanity | runtime's own CLI, all defaults (voice default, max_new_tokens 256, seed 42, threads 5) | "Welcome to audio8 TTS." | 256/256 | 11.89 s of audio, wall 52 s, peak RSS 2.5 GB; Whisper transcript: "now" |

Speed seen on the way (not a valid benchmark): prefill 175 prompt tokens about 8.7 s at 1 thread,
about 115 ms per codec frame at 1 thread and about 96 ms per frame at 4 threads (one frame = 2048 samples at 44.1 kHz = 46 ms),
so even a working model would be slower than real time on this CPU.
